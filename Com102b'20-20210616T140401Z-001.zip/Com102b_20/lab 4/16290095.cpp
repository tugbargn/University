#include <iostream>
using namespace std;

class Rational
{
	public:

	    Rational(){
			n = 1;
			d = 2;
            cout<<"Constructor is called."<<endl;

        }

        Rational(int a ,int b ){
			
            n = a;
            d = b;
            cout<<"Constructor is called."<<endl;
        }

        Rational(Rational &r){
	
            n = r.n;
            d = r.d;   
            cout<<"Copy constructor is called."<<endl;     
        }
        void set(int a ,int b){
		
            n = a;
            d = b;
        }
        Rational add(Rational &r){

            Rational temp;
            temp.n = d * r.n + n * r.d;
            temp.d = d * r.d;
            return temp;
        }

        Rational multiply(Rational &r){

            Rational temp;
            temp.n = n * r.n;
            temp.d = d * r.d;
            return temp;
        }
        void print(){

            cout<<n<<"/"<<d<<endl;
        }
	
	private:
		int n;
		int d;
	
};

int main()
{
	int a, b, c, d;

	cin>>a>>b;

	cin>>c>>d;

	Rational r1(a,b);

	r1.print();

	Rational r2(r1);

	r2.print();

	Rational r3;

	r3. print();
	
	r3.set(c,d);
	
	r3.print();

	Rational r4, r5;

	r4=r3.add(r1);
	r5=r2.multiply(r3);

	r4. print();
	r5. print();

	return 0;
}



