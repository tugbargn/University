
	#include <iostream>
	using namespace std;

	#include <iomanip>
	using namespace std;

	class Time
	{
	public:
	    Time(){
	    
	    }
	    Time(int h_hour, int m_minute, int s_second){
	        hour = h_hour;
	        minute = m_minute;
	        second = s_second;
	        
	    }
	    ~Time(){
	    
	    }
	    Time& operator=(const Time& tGelen){
	       
	        hour = tGelen.hour;
	        minute = tGelen.minute;
	        second = tGelen.second;
	        
	        return *this;
	    }	
		Time operator+=(int gelen){
		    
		    second = second + gelen;
		    
		    if(second >= 60){
		        second -= 60;
		        minute += 1; 
		        if(minute >= 60){
		            minute -= 60;
		            hour += 1;
		            if(hour == 24)
		                hour = 00;
		            if(hour == 0)
		                hour = 00;
                    if(minute == 0)
                        minute = 00;
                    if(second = 0)
                        second = 00;	
		        }
		    }
		    //cout<<"hour: "<<hour<<"min: "<<minute<<"sec: "<<second<<endl;
		    return *this;
		}
		Time operator -= (int gelen){
		    
		    second = second - gelen;
		    
		    if(second < 0){
		        second += 60;
		        minute -= 1;
		        if(minute < 0){
		            minute += 60;
		            hour -= 1;
		            if(hour < 0)
		                hour += 24;
		            if(hour == 24)
		                hour = 00;
		            if(hour == 0)
		                hour = 00;
                    if(minute == 0)
                        minute = 00;
                    if(second = 0)
                        second = 00;	
		            
		        }
		    }
		    //cout<<"hour: "<<hour<<"min: "<<minute<<"sec: "<<second<<endl;
		    return *this;
		   
		}

		Time operator++(){
		   ++second;
		   
		   if(second >= 60){
		        second -= 60;
		        minute += 1; 
		        if(minute >= 60){
		            minute -= 60;
		            hour += 1;
		            if(hour == 24)
		                hour = 00;
		            if(hour == 0)
		                hour = 00;
                    if(minute == 0)
                        minute = 00;
                    if(second = 0)
                        second = 00;	
		        }
		    }
		   //cout<<"hour: "<<hour<<"min: "<<minute<<"sec: "<<second<<endl;
		   return *this;
		}
		
		Time operator ++(int num){
		    Time obj(this->hour,this->minute,this->second);
	        second++;
	        return obj;
		}
		Time operator--(){
		    --second;
		    
		    if(second < 0){
		        second += 60;
		        minute -= 1;
		        if(minute < 0){
		            minute += 60;
		            hour -= 1;
		            if(hour < 0)
		                hour += 24;
		            if(hour == 24)
		                hour = 00;
		            	
		            
		        }
		    }
		    //cout<<"hour: "<<hour<<"min: "<<minute<<"sec: "<<second<<endl;
		    return *this;
		}
		Time operator--(int num){
		    Time obj(this->hour,this->minute,this->second);
	        second--;
	        
	        if(second < 0){
		        second += 60;
		        minute -= 1;
		        if(minute < 0){
		            minute += 60;
		            hour -= 1;
		            if(hour < 0)
		                hour += 24;
		            if(hour == 24)
		                hour = 00;
		            if(hour == 0)
		                hour = 00;
                    if(minute == 0)
                        minute = 00;
                    if(second = 0)
                        second = 00;	
		            
		        }
		    }
	        
	        return obj;	   
		}
		
		friend ostream &operator <<(ostream &out,const Time &t);
		friend istream &operator >>(istream &in, Time &t);
		
	private:
		int hour;
		int minute;
		int second;

	};
ostream &operator <<(ostream &cikti,const Time &tGelen){

    int min = tGelen.minute;
    int sec = tGelen.second;
    int hour = tGelen.hour;
    
    if(sec >= 60){
        min += 1;
        sec -= 60;
        if(min >= 60){
            min -= 60;
            hour += 1;
            if(hour >= 24){
                hour -= 24;
            }
        }
    }
        
    if(hour < 10) 
        cikti<<"0"<<hour;
    else
        cikti<<hour;
    if(min < 10)
        cikti<<":"<<"0"<<min;
    else
        cikti<<":"<<min;
    if(sec < 10)
        cikti<<":"<<"0"<<sec;
    else
        cikti<<":"<<sec;
    return cikti;
}
istream &operator >>(istream &girdi, Time &t){

    girdi>>t.hour;
    girdi>>t.minute;
    girdi>>t.second;
    
    return girdi;
}


int main()
{


Time a;

cin>>a; 

cout<<a<<endl;  //23 59 20

Time b;

b=a; 

cout<<b<<endl;  //23 59 20

b+=40; 

cout<<b<<endl;  //00 00 00

cout<<--b<<endl; //23 59 59

cout<<b--<<endl; //23 59 59

cout<<b<<endl; //23 59 58


b-=50; 

cout<<b<<endl;  //23 59 08

cout<<++b<<endl; //23 59 09

cout<<b++<<endl; //23 59 09

cout<<b<<endl;  //23 59 10

return 0;

}
