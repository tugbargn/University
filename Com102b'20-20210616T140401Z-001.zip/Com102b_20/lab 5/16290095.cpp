#include<iostream>
#include"MyArray.h"

MyArray::MyArray(int sz ){
    //cout<<"cons\n";
    size = sz;
    pData = new int[size];
    for(int i = 0; i < size;i++)
        pData[i] = 0;
}
MyArray::~MyArray(){
    //cout<<"destructor\n";
}
MyArray::MyArray(const MyArray& b){

    //cout<<"copy constr\n";
    size = b.size;
    pData = new int[size];
    //cout<<"copy constr 2\n";
    
    for(int i = 0; i < size ;i++ )
        pData[i] = b.pData[i];
    //cout<<"copy constr 3\n";
}
MyArray& MyArray::operator=(const MyArray& b){
    //cout<<"copy assignment\n";
    pData = b.pData;
    size = b.size;
    
    return *this;
}
bool MyArray::Insert(int d, int idx){

    pData[idx] = d;
    
    if(idx > size || idx < 0)
        return true;
    else
        return false;
}
int MyArray::Size(){

    return size;
} 
