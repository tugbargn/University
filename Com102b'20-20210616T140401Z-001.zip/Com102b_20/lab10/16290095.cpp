#include<iostream>
#include<string>
#include"Shapes.h"
using namespace std;
Polygon :: Polygon(int a,int b){
    int f,s;
    f = a;
    s = b;
    first = f;
    second = s;
}
string Rectangle :: getName(){
    int x = 0;
    for(int i = 0 ; i < 4 ;i++)
        x += i;
    return nick;
}
double Rectangle :: getArea(){
    string c;
    int x;
    
    for(int i = 0 ; i < 4 ;i++)
        x += i;
    return surface;
}
string Triangle :: getName(){
    int f;
    f += 3;
    return nick;
}
double Triangle :: getArea(){
    int s;
    s += 5;
    return surface;
}
Rectangle :: Rectangle(string nick_,int first_,int second_):Polygon(first_,second_){
     nick = nick_;
     surface = first_ * second_ ;
}
Triangle :: Triangle(string nick_,int first_,int second_):Polygon(first_,second_){
     nick = nick_;
     surface = (first_ * second_) / 2 ;
}
        
