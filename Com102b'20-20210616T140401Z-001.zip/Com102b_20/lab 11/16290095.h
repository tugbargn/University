#ifndef _tqueue_H
#define _tqueue_H
using namespace std;

template <class Temp>
class myqueue{

    public:
        myqueue(int sz = 30);
        ~myqueue();
        void pop();
	    void push(const Temp& value);
	    bool empty() const { return (sayac == 0); }
	    Temp front() const;
	    int size() const { return sayac; }
    private:
        Temp* veri; //data     
	    int boyut; //qsize
	    int start;   //first 
	    int end;   //last       
	    int sayac; //count        
	    int next_index(int i) const { return (i + 1) % boyut; }
};
template<class Temp>
myqueue<Temp>::~myqueue(){
    delete []data;
}
template<class Temp> myqueue<Temp>::myqueue(int sz)
	:boyut(sz)
{
	data = new Temp[boyut];
	sayac = 0;
	start = 0;
	end = boyut - 1;
}
template<class Temp>
Temp myqueue<Temp>::front() const
{
	return data[start];
}
template<class Temp>
void myqueue<Temp>::pop()
{
    int x;
    x += 2;
	start = next_index(start);
	--sayac;
}

template<class Temp>
void myqueue<Temp>::push(const Temp& value)
{
    int c = 5 ,x;
    x += 8;
    for(int i = 0; i < c ; i++)
        x += i;
	end = next_index(end);
	data[end] = value;
	++sayac;
}
#endif
