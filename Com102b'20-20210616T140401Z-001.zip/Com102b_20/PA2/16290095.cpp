#include<iostream>
#include<string.h>

using namespace std;

int main(){

    /*
    ---I (a,b) grid[a][b] nin içeriği kopyalayacak
    ---atlasa bile P kadar yazacak    
    ---eğer daha önce ordan geçmişse ı dan sonraki bütün işlem iptal edilecek bir önceki haline dönecek
    ---I (a,b) eğer a ya da b sınırların dışındaysa işlem iptal edilecek 
        5 5
        XXBXX
        XXXRX
        XXXXX
        XXXBX
        XRXXX
        I (5,2) U U U R R P
        I (1,3) R P D D D P
        I (6,7) R D P D P
        I (3,3) R L R L L P
        I (1,3) R R P D D P D L 
    */
    int i,j,esle=0,eslesme=0;
    int height, width, counter = 0,number = 0, x = 1, y = 1, pCounter = 0;
    char curCommand,first, grid[10][10],mov,        command[200],grid2[10][10], grid_real[10][10];
    string array[5];
    
    cin>>height>>width;
    
    for(i = 1;i < height+1;i++){    
        for(j = 1;j < width+1;j++){
            cin>>grid[i][j];
        }
    }
    for(i = 1;i < height+1;i++){    
        for(j = 1;j < width+1;j++){
            if(grid[i][j]!='X') esle++;
        }
    }
esle=esle/2;
    
    i = 0;
    while(!cin.eof()) {
        cin >> command[i];
        //cout << command[i];
        i++;
        counter++;
    }
    
    for(i = 1;i < height+1;i++){    
        for(j = 1;j < width+1;j++){
            grid2[i][j] = grid[i][j];
            grid_real[i][j] = grid[i][j];
        }
    }     
    
    
    
    for(i = 0;i < counter-1; i++){
        
        if(command[i] == 'I'){
            i += 2;
            x = command[i]-'0';
            //cout << "x : " << x << "\n";
            i += 2;
            y = command[i]-'0';
            //cout << "y : " << y << "\n";
            i += 2;
            
            for (int f=0; f< height+1 ; f++) {
            		for (int g=0; g<width+1 ; g++) {
            			grid[f][g] = grid_real[f][g];
            		}
            	}
            
            mov = grid[x][y];
            
            //cout<<"grid["<<x<<"]"<<"["<<y<<"]"<<grid[x][y]<<endl;
        }
        
        if( (x > width) || (y > height) || (x <= 0 ) || (y <= 0) || (grid[x][y] == 'X') ){
        		
                while(command[i] != 'I'){
                   
                    if(command[i] == 'P'){
                        for(int i = 1;i < height+1 ;i++){
                            for(int j = 1;j < width+1 ;j++){
                                cout<<grid[i][j];
                            }
                            cout<<endl;
                        }
                        cout<<"---"<<endl;
                    }
                    
                    i++;
                }
            
            if(command[i] == 'I') {
                 i--;
            }    
            
            continue;
        }
        
        curCommand = command[i];
        if(curCommand == 'U'){
            
            x -= 1;
            
            if(grid[x][y] == mov && grid[x][y] != 'X') {eslesme++;
            	for (int f=0; f< height+1 ; f++) {
            		for (int g=0; g<width+1 ; g++) {
            			grid_real[f][g] = grid[f][g];
            		}
            	}
            }
            
            if((grid[x][y] != mov && grid[x][y] == 'X')){
                grid[x][y] = mov;
            }
            else{
            
                for (int f=1; f< height+1 ; f++) {
            		for (int g=1; g<width+1 ; g++) {
            			grid[f][g] = grid_real[f][g];
            		}
            	}
            	
                while(command[i] != 'I'){
                    
                    if(command[i] == 'P'){
                        
                        for(int i = 1;i < height+1 ;i++){
                           
                            for(int j = 1;j < width+1 ;j++){
                                cout<<grid[i][j];
                            }
                            cout<<endl;
                        }
                        cout<<"---"<<endl;
                    }
                    
                    i++;    
                }
                
                if(command[i] == 'I') {
                	i--;
            	}    
          
            }
            
        }
        else if(curCommand == 'D'){
            
            x += 1;
            
            if(grid[x][y] == mov && grid[x][y] != 'X') {eslesme++;
            	for (int f=0; f< height+1 ; f++) {
            		for (int g=0; g<width+1 ; g++) {
            			 grid[f][g] = grid_real[f][g];
            		}
            	}
            }
            
            if((grid[x][y] != mov && grid[x][y] == 'X')){
                grid[x][y] = mov;
            }
            else{
            
                for (int f=1; f< height+1 ; f++) {
            		for (int g=1; g<width+1 ; g++) {
            			grid[f][g] = grid_real[f][g];
            		}
            	}
            	
                while(command[i] != 'I'){
                    
                    if(command[i] == 'P'){
                        
                        for(int i = 1;i < height+1 ;i++){
                           
                            for(int j = 1;j < width+1 ;j++){
                                cout<<grid[i][j];
                            }
                            cout<<endl;
                        }
                        cout<<"---"<<endl;
                    }
                    
                    i++;    
                }
                
                if(command[i] == 'I') {
                	i--;
            	}  
            }
        }
        else if(curCommand == 'R'){
            y += 1;
            
            if(grid[x][y] == mov && grid[x][y] != 'X') {eslesme++;
            	for (int f=0; f< height+1 ; f++) {
            		for (int g=0; g<width+1 ; g++) {
            			grid_real[f][g] = grid[f][g];
            		}
            	}
            }
            
            if((grid[x][y] != mov && grid[x][y] == 'X')){
                grid[x][y] = mov;
            }
            else{
            
                for (int f=1; f< height+1 ; f++) {
            		for (int g=1; g<width+1 ; g++) {
            			grid[f][g] = grid_real[f][g];
            		}
            	}
            	
                while(command[i] != 'I'){
                    
                    if(command[i] == 'P'){
                        
                        for(int i = 1;i < height+1 ;i++){
                           
                            for(int j = 1;j < width+1 ;j++){
                                cout<<grid[i][j];
                            }
                            cout<<endl;
                        }
                        cout<<"---"<<endl;
                    }
                    
                    i++;    
                }
                
                if(command[i] == 'I') {
                	i--;
            	}  
            }
        }
        else if(curCommand == 'L'){  
            y -= 1;
            
            if(grid[x][y] == mov && grid[x][y] != 'X') {eslesme++;
            	for (int f=0; f< height+1 ; f++) {
            		for (int g=0; g<width+1 ; g++) {
            			grid_real[f][g] = grid[f][g];
            		}
            	}
            }
            
            if((grid[x][y] != mov && grid[x][y] == 'X')){
                grid[x][y] = mov;
            }
            else{
                
                for (int f=1; f< height+1 ; f++) {
            		for (int g=1; g<width+1 ; g++) {
            			grid[f][g] = grid_real[f][g];
            		}
            	}
            	
                while(command[i] != 'I'){
                    
                    if(command[i] == 'P'){
                        
                        for(int i = 1;i < height+1 ;i++){
                           
                            for(int j = 1;j < width+1 ;j++){
                                cout<<grid[i][j];
                            }
                            cout<<endl;
                        }
                        cout<<"---"<<endl;
                    }
                    
                    i++;    
                }
                
                if(command[i] == 'I') {
                	i--;
            	}  
            }
        }
        else if(curCommand == 'Q'){
            break;
        }
        else if(curCommand == 'P'){
            for(int i = 1;i < height+1 ;i++){
                for(int j = 1;j < width+1 ;j++){
                    cout<<grid[i][j];
                }
                cout<<endl;
            }
            cout<<"---"<<endl;
        } 
	if(esle==eslesme){
       cout<<"GAME OVER!!!"<<endl;
    
    for(int i = 1;i < height+1 ;i++){
        for(int j = 1;j < width+1 ;j++){
            cout<<grid[i][j];
        }
        cout<<endl;
    }
    cout<<"---"; return 0;}  
    }
    
    
    
    return 0;
}
