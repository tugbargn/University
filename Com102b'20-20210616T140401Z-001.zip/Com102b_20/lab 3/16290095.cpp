
#include <iostream>
using namespace std;

class Date
{
	public:
        Date(){
            cin>>day>>month>>year;
        }
        Date(int d,int m,int y){
            day = d;
            month = m;
            year = y;
        }

        void setDate(int d,int m,int y){
            day = d;
            month = m;
            year = y;
        }

        void printDate1(){

            cout<<day<<"."<<month<<"."<<year<<endl;
        }

        void printDate2(){

            cout<<day<<"/"<<month<<"/"<<year<<endl;
        }
	private:
        int day;
        int month;
        int year;
		
};

int main()
{
	int day1, month1, year1;
	int day2, month2, year2;

	cin>>day1>>month1>>year1;
	cin>>day2>>month2>>year2;

	Date d1;
	Date d2(day1,month1,year1);
	
	Date d3;
	
	d3.printDate1();
	d2.printDate1();
	d1.printDate1();
	
	d1.printDate2();
	d2.printDate2();
	d3.printDate2();
	
	d2.setDate(day2,month2,year2);
	
	d2.printDate1();
	d2.printDate2();

	return 0;
}

