#include <iostream>
using namespace std;

class Complex
{
	public:
        /*
        -2.1 -3.4i
        3.5 2.4i
        
        Copy constructor is called.
        -2.1-3.4i
        3.5+2.4i
        -2.1-3.4i
        1.4-1i
        0.81-16.94i
        */
        Complex(){
        
            double realPart;
            double imagPart;
               
        }
        ~Complex(){
        
        }
        Complex(double realNumber,double imagNumber){
             //copy r and i
             double realPart;
             double imagPart;
             
             realPart = realNumber;
             real = realPart;
             
             imagPart = imagNumber;
             
             imag = imagPart; 
        }
        Complex(const Complex& number){
        
            string array[4];
            double realPart;
            double imagPart;
            
            array[0] = "Copy";
            array[1] = "constructor";
            array[2] = "is";
            array[3] = "called.";
            
            for(int i = 0; i < 4 ; i++)
                cout<<array[i]<<" ";
            cout<<"\n";
            
            //cout<<"Copy constructor is called.\n";
            realPart = number.real;
            imagPart = number.imag;
            
            real = realPart;
            imag = imagPart;
            
        }
        Complex& operator=(const Complex &number){
        
            double realPart;
            
            realPart = number.real;
            real = realPart;
            
            double imagPart;
            
            imagPart = number.imag;
            imag = imagPart;
            
            return *this;
        }
        Complex operator+(const Complex &number){
        
            Complex inside;
            
            double realPart;
            
            realPart = real + number.real;
            
            double imagPart;
            
            imagPart += imag;
            imagPart += number.imag;
            
            inside.real = realPart;
            inside.imag = imagPart;
            
            
            return inside;
            
        }
        Complex operator*(const Complex& number){
        
            Complex inside;
            
            double realPart1 = real * number.real;
            double realPart2 = -(imag * number.imag);
            
            inside.real =  realPart1 + realPart2;
            
            double imagPart1 = real * number.imag;
            double imagPart2 = imag * number.real;
            
            inside.imag = imagPart1 + imagPart2;
            
            return inside;
        }
        
        friend ostream &operator << (ostream &cikti, const Complex &number); 
        
        friend istream &operator >> (istream &girdi,  Complex &number);  
        
	private:
		double real;
		double imag;

};

istream &operator >> (istream &girdi,  Complex &number) 
{  
    char a; 
    double  realPart;
    double imagPart;
       
    girdi >> realPart;  
    girdi >> imagPart;
    girdi.ignore(); 
    
    number.real = realPart;
    number.imag = imagPart;
    
   
    return girdi; 
}
ostream &operator << (ostream &cikti, const Complex &number) 
{ 
    double realPart;
    double imagPart;
    
    realPart = number.real;
    imagPart = number.imag;
    
    if(imagPart > 0){
    
      cikti<<realPart<< "+" <<imagPart <<"i"<< endl; 
    }
    else{
      cikti<<realPart<<imagPart<<"i"<<endl;
    }   
    return cikti; 
} 
/*
ostream &operator << (ostream &cikti, const Complex &number) 
{
     if(number.imag > 0){
    
      cikti<<number.real<< "+" <<number.imag <<"i"<< endl; 
    }
    else{
      cikti<<number.real<<number.imag<<"i"<<endl;
    }   
    return cikti;
}
    */    
int main()
{
	Complex c1;

	cin>>c1;

	Complex c2;

	cin>>c2;

	Complex c3(c1);

	Complex c4, c5;

	c4=c2+c3;
	c5=c2*c3;

	cout<<c1<<c2<<c3<<c4<<c5;

	return 0;
}



