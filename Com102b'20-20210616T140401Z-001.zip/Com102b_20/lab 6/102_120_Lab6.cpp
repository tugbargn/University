#include <iostream>
using namespace std;

class Complex
{
	public:



	private:
		double real;
		double imag;

};


int main()
{
	Complex c1;

	cin>>c1;

	Complex c2;

	cin>>c2;

	Complex c3(c1);

	Complex c4, c5;

	c4=c2+c3;
	c5=c2*c3;

	cout<<c1<<c2<<c3<<c4<<c5;

	return 0;
}



