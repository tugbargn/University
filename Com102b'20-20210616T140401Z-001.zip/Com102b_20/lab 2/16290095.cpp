
#include <iostream>
using namespace std;

class PrintShape
{
	public:
		PrintShape(){
             cout<<"*****"<<endl<<"*****"<<endl<<"*****";
                  
        }
	    PrintShape(int i1,int i2,char c1){

            a = i1;
            b = i2;
            c = c1;
            cout<<"*"<<endl<<"**"<<endl<<"***\n"<<endl;
	    }
        void set(int i1,int i2,char c1){

            a = i1;
            b = i2;
            c = c1;
        }

        int geta(){return a;}
        int getb(){return b;}
        char getc(){return c;}

	    void printRectangle(){
            int x = 0;
            for(int i = 0 ;i < a; i++){
                for(int j = 0;j < b;j++){
                    cout<<c;
                }
            cout<<endl;
            }
        }    
            
        void printTriangle(){
             int k = 1;
            for(int i = 0;i < a; i++){
                k++;
                for(int j = 1; j < k;j++){
                   cout<<c;
                }           
              
            cout<<endl;
	        }
        }

            
	private:
		int a;//7
		int b;//3
		char c;//@
};

int main()
{
	int i1, i2, i3, i4;
	char c1, c2;

	cin>>i1>>i2>>c1;
	cin>>i3>>i4>>c2;

	PrintShape ps1;

	ps1.printRectangle();
	cout<<endl;
	ps1.printTriangle();
	cout<<endl;

	PrintShape ps2(i1,i2,c1);

	ps2.printRectangle();
	cout<<endl;
	ps2.printTriangle();
	cout<<endl;

	ps2.set(i3,i4,c2);

	ps2.printRectangle();
	cout<<endl;
	ps2.printTriangle();
	cout<<endl;

	return 0;
}

