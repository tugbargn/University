#include <iostream>
#include<string.h>
using namespace std;

int main()
{
	int i = 0,counter = 0,vocabsize = 0,size[1000];
	string s,text[1000],word[1000];
	
	while (cin>>s) {//take date from user 
		if(s != " "){
			counter++;
			text[i] = s;
			i++;
		}
	
	}
	//cout<<"1"<<endl;
	for(int i = 0; i < counter; i++)
	{
	    for(int j = 0 ; 1 ; j++)
	    {
	       if(text[i][j]!='\0')
	       {
	            if(text[i][j]>='A'&&text[i][j]<='Z')
	                text[i][j]+='a'-'A';
	            else
	                continue;
	       }
           else
	        break;
	    }
	
	}
	//cout<<"2"<<endl;
	for(int i = 0; i < counter; i++){
	    for(int j = 0; j < counter ; j++){
	        if(text[i]<text[j]){
	            //cout<<s<<endl;
	            s = text[i];
	            text[i] = text[j];
	            text[j] = s;
	        }
	    }
	}
	//cout<<"3"<<endl;
	for(int i = 0; i < counter; i++)
	    size[i] = 1;
	
	for(int i= 0; i < counter ; i++){
	    for(int j = 0; j < counter; j++){
	        
	        if(i != j){
	        
	            if(text[i] == text[j]){
	            
	                text[j] = "*";
	                size[i] += 1;
	            }
	            else{
	                continue;
	            }
	        }
	        else{
	            continue;
	        }
	    }
	}
	//cout<<"4"<<endl;
	for(int i = 0; i < counter; i++)
	    if(text[i] == "*")
	            continue;
	        else
	            vocabsize++;
	       
	    cout<<"Vocabulary Size = "<<vocabsize<<endl;
	    
	for(int i = 0; i < counter; i++){
	    if(text[i] == "*")
	        continue;
	    else    
	        cout<<text[i]<<" "<<size[i]<<endl;
	}    
	//print(&text[0],&size[0],counter);
	
	    
}
