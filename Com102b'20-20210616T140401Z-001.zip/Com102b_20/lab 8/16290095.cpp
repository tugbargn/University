#include <iostream>
using namespace std;

class A{
    
    public:
    
        A(int n1){
            int var = n1;
            int val = 3;
            
            string b[2] = {"Constructor","A:"};
            
            firstNumber = var;
            secondNumber = val;
            
           
            
            cout<<b[0]<<" "<<b[1];
            cout<<firstNumber<<" ";
            cout<<secondNumber<<endl;
            
            
        }
        A(int a, int b){
            int fdegisken = a;
            int sdegisken = b;
            
            string d[2] = {"Constructor","A:"};
            
            firstNumber = fdegisken;
            secondNumber = sdegisken;
            
            
            cout<<d[0]<<" "<<d[1];
            cout<<firstNumber<<" ";
            cout<<secondNumber<<endl;
        }
        ~A(){
            
            string e[2] = {"Destructor","A:"};
            
            cout<<e[0]<<" "<<e[1];
            cout<<firstNumber<<" ";
            cout<<secondNumber<<endl;
        }

    private:
        int firstNumber;
        int secondNumber;
};

class B: A{//inherited

    public:
        B(int m1,int m2):A(m2,2){
            
            int d1 = m1;
            int d2 = m2;
            int d3 = 2;
            string f[2] = {"Constructor","B:"};
            
            number1 = d1;
            number2 = d2;
            number3 = d3;
            
            
            
            cout<<f[0]<<" "<<f[1];
            cout<<number1<<" ";
            cout<<number2<<" "<<number3<<endl; 
        }
        B(int m):A(1,2){
        
            int deg1 = m;
            int deg2 = 1;
            int deg3 = 2;
            
            string g[2] = {"Constructor","B:"};
            
            number1 = deg1;
            number2 = deg2;
            number3 = deg3;
            
            
            
            cout<<g[0]<<" "<<g[1];
            cout<<number1<<" ";
            cout<<number2<<" "<<number3<<endl;
        }
        ~B(){
            string b[2] = {"Destructor","B:"};
            
            cout<<b[0]<<" "<<b[1];
            cout<<number1<<" ";
            cout<<number2<<" "<<number3<<endl;
        }
    private:
        int number1;
        int number2;
        int number3;
};

void function1(int a, int b)
{
	A a1(a); //a = i = 55;
	B b1(b); //b = j = 67

}
int main()
{
	int c, d, i, j;
	cin>>c>>d; //c = 27 d = 45
	cin>>i>>j; //i = 55 j = 67

	function1(i,j);

	B x(c,d);

	return 0;
}

